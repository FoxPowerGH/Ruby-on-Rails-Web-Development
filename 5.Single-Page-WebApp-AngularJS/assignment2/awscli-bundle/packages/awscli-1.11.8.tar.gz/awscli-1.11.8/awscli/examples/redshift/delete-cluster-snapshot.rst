Delete a Cluster Snapshot
-------------------------

This example deletes a cluster snapshot.

Command::

   aws redshift delete-cluster-snapshot --snapshot-identifier my-snapshot-id

