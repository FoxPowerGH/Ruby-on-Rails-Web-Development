**To get information about a deployment**

Command::

  aws apigateway get-deployment --rest-api-id 1234123412 --deployment-id ztt4m2 --region us-west-2

Output::

  {
      "description": "myDeployment",
      "id": "ztt4m2",
      "createdDate": 1455218022
  }

